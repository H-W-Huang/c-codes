#include <stdio.h>
#include "datatype.h"

USER * loadFromFile(char * filename)
{

    printf("load from file function. %s \n", filename);
    system("pause");
    return NULL;
}

int saveToFile(char * filename, USER *head)
{
    printf("save to file function. %s \n", filename);
    system("pause");
    return 1;
}
